Dont copy this mod or any of its contents

--To intsall follow instrutions-- I(for windows only)

1.Find the FansMod 2.1
2.Copy itm (ctrl + c)
3.Go C:\Program Files (x86)\Steam\steamapps\common\Software Inc\Mods
4.Paste it (ctrl + v)
5.Play the mod